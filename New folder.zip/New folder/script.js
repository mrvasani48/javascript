async function getData() {
    const apiRes = await fetch('https://api.dictionaryapi.dev/api/v2/entries/en_US/hello')
    const data = await apiRes.json()
    const table = document.querySelector('table')
    data.forEach(element => {
        let newRow = document.createElement('tr')

        let wordCol = document.createElement('a')


        for (let i in element) {
            let col = document.createElement('td')
            if (typeof element[i] == 'object') {
                col.innerText = element[i].length
            }
            else {
                col.innerText = element[i]
            }
            newRow.append(col)
        }
        table.append(newRow)
    });
}
getData()